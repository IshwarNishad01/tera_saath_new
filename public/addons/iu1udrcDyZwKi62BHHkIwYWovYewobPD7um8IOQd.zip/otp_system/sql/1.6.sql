INSERT INTO `otp_configurations` (`id`, `type`, `value`, `created_at`, `updated_at`) VALUES (NULL, 'mimsms', '0', current_timestamp(), current_timestamp());
COMMIT;
